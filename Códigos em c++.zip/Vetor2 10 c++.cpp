#include <iostream>

int main() {
    const int tamanhoVetor = 10;
    int espectadores[tamanhoVetor];

    // Preenchendo o vetor com o número de espectadores em cada jogo
    std::cout << "Digite o número de espectadores em cada jogo:\n";
    for (int i = 0; i < tamanhoVetor; ++i) {
        std::cin >> espectadores[i];
    }

    // Contando o número de jogos com público superior a 50.000 espectadores
    int jogosComMaisDe50MilEspectadores = 0;
    for (int i = 0; i < tamanhoVetor; ++i) {
        if (espectadores[i] > 50000) {
            jogosComMaisDe50MilEspectadores++;
        }
    }

    // Exibindo o número de jogos com público superior a 50.000 espectadores
    std::cout << "Número de jogos com público superior a 50.000 espectadores: " << jogosComMaisDe50MilEspectadores << std::endl;

    return 0;
}
