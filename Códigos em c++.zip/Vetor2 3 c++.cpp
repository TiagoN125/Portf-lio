#include <iostream>

int main() {
    const int tamanhoVetor = 10;
    int idades[tamanhoVetor];

    // Lendo as idades das jogadoras
    std::cout << "Digite as idades das jogadoras:\n";
    for (int i = 0; i < tamanhoVetor; ++i) {
        std::cin >> idades[i];
    }

    // Calculando a média das idades
    int soma = 0;
    for (int i = 0; i < tamanhoVetor; ++i) {
        soma += idades[i];
    }

    double media = static_cast<double>(soma) / tamanhoVetor;

    // Exibindo a média das idades
    std::cout << "A média das idades é: " << media << std::endl;

    return 0;
}
