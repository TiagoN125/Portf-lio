#include <iostream>
#include <limits> // Para usar o std::numeric_limits

int main() {
    const int tamanhoVetor = 6;
    float alturas[tamanhoVetor];

    // Preenchendo o vetor com valores digitados pelo usuário
    std::cout << "Digite as alturas das jogadoras (em metros):\n";
    for (int i = 0; i < tamanhoVetor; ++i) {
        std::cin >> alturas[i];
    }

    // Inicializando as variáveis para armazenar a maior e a menor altura
    float maiorAltura = std::numeric_limits<float>::min(); // Menor valor possível para float
    float menorAltura = std::numeric_limits<float>::max(); // Maior valor possível para float

    // Encontrando a maior e a menor altura
    for (int i = 0; i < tamanhoVetor; ++i) {
        if (alturas[i] > maiorAltura) {
            maiorAltura = alturas[i];
        }
        if (alturas[i] < menorAltura) {
            menorAltura = alturas[i];
        }
    }

    // Exibindo a maior e a menor altura
    std::cout << "Maior altura: " << maiorAltura << " metros\n";
    std::cout << "Menor altura: " << menorAltura << " metros\n";

    return 0;
}
