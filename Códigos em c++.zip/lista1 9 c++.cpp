#include <iostream>
using namespace std;

int main() {
    int numero, maior, menor;
    bool primeiroNumero = true;

    cout << "Digite uma sequência de números inteiros (digite 0 para encerrar):" << endl;

    while (true) {
        cin >> numero;

        if (numero == 0) {
            break; // Encerra o loop quando o número digitado for zero
        }

        if (primeiroNumero) {
            maior = numero;
            menor = numero;
            primeiroNumero = false;
        } else {
            if (numero > maior) {
                maior = numero;
            }

            if (numero < menor) {
                menor = numero;
            }
        }
    }

    if (primeiroNumero) {
        cout << "Nenhum número foi digitado." << endl;
    } else {
        cout << "Maior valor: " << maior << endl;
        cout << "Menor valor: " << menor << endl;
    }

    return 0;
}