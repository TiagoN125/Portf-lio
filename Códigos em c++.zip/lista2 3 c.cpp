#include <iostream>
using namespace std;

int main() {
    int numero, pares = 0, impares = 0;

    cout << "Digite uma sequência de números inteiros (digite 0 para encerrar):" << endl;

    while (true) {
        cin >> numero;
        
        if (numero == 0) {
            break; // Encerra o loop quando o número digitado for zero
        }

        if (numero % 2 == 0) {
            pares++;
        } else {
            impares++;
        }
    }

    cout << "Quantidade de números pares: " << pares << endl;
    cout << "Quantidade de números ímpares: " << impares << endl;

    return 0;
}
