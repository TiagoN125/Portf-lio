#include <iostream>
using namespace std;

int main() {
    double precoMascara, dinheiroBatman;

    cout << "Digite o preço de uma máscara (em reais): ";
    cin >> precoMascara;

    cout << "Digite a quantidade de dinheiro que o Batman possui (em reais): ";
    cin >> dinheiroBatman;

    if (dinheiroBatman >= precoMascara) {
        double dinheiroRestante = dinheiroBatman - precoMascara;
        cout << "O Batman pode comprar a máscara de reserva!" << endl;
        cout << "Valor da compra: R$ " << precoMascara << endl;
        cout << "Dinheiro restante: R$ " << dinheiroRestante << endl;
    } else {
        cout << "O Batman não tem dinheiro suficiente para comprar a máscara de reserva." << endl;
    }

    return 0;
}
