#include <iostream>

using namespace std;

float calcular_area_retangulo(float base, float altura) {
    return base * altura;
}

int main() {
    try {
        float base, altura;
        cout << "Digite a medida da base do retângulo: ";
        cin >> base;
        cout << "Digite a medida da altura do retângulo: ";
        cin >> altura;

        if (base <= 0 || altura <= 0) {
            cout << "As medidas devem ser valores positivos." << endl;
            return 1;
        }

        float area = calcular_area_retangulo(base, altura);
        cout << "A área do retângulo é: " << fixed << area << endl;
    } catch (const exception& e) {
        cout << "Entrada inválida. Certifique-se de digitar números válidos." << endl;
        return 1;
    }

    return 0;
}
