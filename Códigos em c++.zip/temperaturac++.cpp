#include <iostream>

int main() {
    double celsius, fahrenheit;

    // Solicita ao usuário que digite a temperatura em graus Celsius
    std::cout << "Digite a temperatura em graus Celsius: ";
    std::cin >> celsius;

    // Converte a temperatura para Fahrenheit usando a fórmula de conversão
    fahrenheit = (celsius * 9.0 / 5.0) + 32.0;

    // Exibe o resultado da conversão
    std::cout << "A temperatura em Fahrenheit é: " << fahrenheit << " °F" << std::endl;

    return 0;
}
