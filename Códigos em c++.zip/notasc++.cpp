#include <iostream>

int main() {
    double nota1, nota2, nota3;

    // Solicita ao usuário que digite as três notas
    std::cout << "Digite a primeira nota: ";
    std::cin >> nota1;

    std::cout << "Digite a segunda nota: ";
    std::cin >> nota2;

    std::cout << "Digite a terceira nota: ";
    std::cin >> nota3;

    // Calcula a média das três notas
    double media = (nota1 + nota2 + nota3) / 3;

    // Exibe a média
    std::cout << "A média das três notas é: " << media << std::endl;

    return 0;
}
