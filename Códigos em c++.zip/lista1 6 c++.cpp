#include <iostream>
using namespace std;

bool verificarTriangulo(double lado1, double lado2, double lado3) {
    return (lado1 + lado2 > lado3) && (lado1 + lado3 > lado2) && (lado2 + lado3 > lado1);
}

string classificarTriangulo(double lado1, double lado2, double lado3) {
    if (lado1 == lado2 && lado2 == lado3) {
        return "Triângulo Equilátero";
    } else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
        return "Triângulo Isósceles";
    } else {
        return "Triângulo Escaleno";
    }
}

int main() {
    double lado1, lado2, lado3;

    cout << "Digite os três lados do triângulo: " << endl;
    cin >> lado1 >> lado2 >> lado3;

    if (verificarTriangulo(lado1, lado2, lado3)) {
        cout << "É possível formar um triângulo." << endl;
        cout << "Classificação do triângulo: " << classificarTriangulo(lado1, lado2, lado3) << endl;
    } else {
        cout << "Não é possível formar um triângulo com esses valores." << endl;
    }

    return 0;
}