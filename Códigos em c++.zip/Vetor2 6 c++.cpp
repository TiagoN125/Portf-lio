#include <iostream>

int main() {
    const int tamanhoVetor = 5;
    int golsPorPartida[tamanhoVetor];

    // Preenchendo o vetor com o número de gols por partida
    std::cout << "Digite o número de gols marcados em cada partida:\n";
    for (int i = 0; i < tamanhoVetor; ++i) {
        std::cin >> golsPorPartida[i];
    }

    // Calculando o total de gols marcados
    int totalGols = 0;
    for (int i = 0; i < tamanhoVetor; ++i) {
        totalGols += golsPorPartida[i];
    }

    // Exibindo o total de gols marcados
    std::cout << "Total de gols marcados pela seleção: " << totalGols << std::endl;

    return 0;
}
