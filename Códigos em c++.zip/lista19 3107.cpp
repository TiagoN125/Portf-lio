#include <iostream>

int main() {
    const int tamanhoVetor = 5;
    int vetor1[tamanhoVetor], vetor2[tamanhoVetor], vetorSoma[tamanhoVetor];

    std::cout << "Digite " << tamanhoVetor << " valores inteiros para o vetor 1:\n";
    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << "Elemento " << i + 1 << ": ";
        std::cin >> vetor1[i];
    }

    std::cout << "\nDigite " << tamanhoVetor << " valores inteiros para o vetor 2:\n";
    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << "Elemento " << i + 1 << ": ";
        std::cin >> vetor2[i];
    }

    for (int i = 0; i < tamanhoVetor; i++) {
        vetorSoma[i] = vetor1[i] + vetor2[i];
    }

    std::cout << "\nConteúdo do terceiro vetor (soma dos dois vetores):\n";
    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << vetorSoma[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}
