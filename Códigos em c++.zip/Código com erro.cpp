#include <iostream>

int main() {
    r (int i = 0; i < tamanhoVetor; i++) {
        std::cout << "Digite o valor do elemento " << i << ": "; // Deve ser "i + 1" para começar de 1 ao mostrar a mensagem
        std::cin >> vetor[i]; // Falta o índice "i" para acessar a posição correta do vetor
    }

    // Calculando a média dos valores
     soma = 0;
    for (int i = 0; i < tamanhoVetor; i++) {
        soma += vetor[i]; // Falta o índice "i" para acessar a posição correta do vetor
    }
    float media = soma / tamanhoVetor; // É melhor usar float em vez de int para manter a precisão da média

    std::cout << "A media dos valores e: " << media << std::endl; // A palavra "média" está escrita errada

    return 0; // Falta um ponto e vírgula aqui

