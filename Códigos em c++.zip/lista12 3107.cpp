#include <iostream>
#include <string>

int main() {
    const int tamanhoVetor = 5;
    std::string frutas[tamanhoVetor];

    std::cout << "Digite o nome de " << tamanhoVetor << " frutas:\n";

    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << "Fruta " << i + 1 << ": ";
        std::cin >> frutas[i];
    }

    std::cout << "\nNomes das frutas:\n";
    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << frutas[i] << std::endl;
    }

    return 0;
}
