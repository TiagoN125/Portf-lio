#include <iostream>
using namespace std;

int calcularSomaDigitos(int numero) {
    int soma = 0;
    while (numero != 0) {
        soma += numero % 10; // Obtém o último dígito do número e soma à variável 'soma'
        numero /= 10; // Remove o último dígito do número
    }
    return soma;
}

int main() {
    int numero;

    cout << "Digite um número inteiro positivo: ";
    cin >> numero;

    if (numero < 0) {
        cout << "O número deve ser positivo." << endl;
        return 1;
    }

    int somaDosDigitos = calcularSomaDigitos(numero);
    cout << "A soma dos dígitos do número é: " << somaDosDigitos << endl;

    return 0;
}
