#include <iostream>

int main() {
    const int tamanhoVetor = 10;
    int vetor[tamanhoVetor];
    int soma = 0;

    std::cout << "Digite " << tamanhoVetor << " valores inteiros:\n";

    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << "Elemento " << i + 1 << ": ";
        std::cin >> vetor[i];
        soma += vetor[i];
    }

    double media = static_cast<double>(soma) / tamanhoVetor;

    std::cout << "\nA média dos valores presentes no vetor é: " << media << std::endl;

    return 0;
}
