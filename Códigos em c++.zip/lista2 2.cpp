#include <iostream>
#include <vector>
using namespace std;

bool verificarPrimo(int numero) {
    if (numero <= 1) {
        return false; // Números menores ou iguais a 1 não são primos
    }

    vector<bool> primo(numero + 1, true);

    primo[0] = primo[1] = false;

    for (int i = 2; i * i <= numero; i++) {
        if (primo[i]) {
            for (int j = i * i; j <= numero; j += i) {
                primo[j] = false;
            }
        }
    }

    return primo[numero];
}

int main() {
    int numero;

    cout << "Digite um número inteiro: ";
    cin >> numero;

    if (verificarPrimo(numero)) {
        cout << numero << " é um número primo." << endl;
    } else {
        cout << numero << " não é um número primo." << endl;
    }

    return 0;
}
