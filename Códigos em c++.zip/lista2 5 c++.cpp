#include <iostream>
#include <cctype>
#include <string>
using namespace std;

bool verificarPalindromo(string palavra) {
    // Remover espaços da palavra original
    string palavraSemEspacos;
    for (char c : palavra) {
        if (!isspace(c)) {
            palavraSemEspacos += tolower(c);
        }
    }

    // Verificar se a palavra sem espaços é um palíndromo
    int tamanho = palavraSemEspacos.length();
    for (int i = 0; i < tamanho / 2; i++) {
        if (palavraSemEspacos[i] != palavraSemEspacos[tamanho - 1 - i]) {
            return false;
        }
    }

    return true;
}

int main() {
    string palavra;

    cout << "Digite uma palavra ou frase: ";
    getline(cin, palavra);

    if (verificarPalindromo(palavra)) {
        cout << "É um palíndromo." << endl;
    } else {
        cout << "Não é um palíndromo." << endl;
    }

    return 0;
}
