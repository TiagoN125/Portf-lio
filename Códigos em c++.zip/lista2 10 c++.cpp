#include <iostream>
#include <iomanip>
using namespace std;

double calcularPi(int numIteracoes) {
    double pi = 0.0;
    int denominador = 1;
    bool adicionar = true;

    for (int i = 0; i < numIteracoes; i++) {
        if (adicionar) {
            pi += 1.0 / denominador;
        } else {
            pi -= 1.0 / denominador;
        }

        adicionar = !adicionar;
        denominador += 2;
    }

    return 4 * pi;
}

int main() {
    int numIteracoes;

    cout << "Digite o número de iterações para calcular o valor de π (pi): ";
    cin >> numIteracoes;

    double valorPi = calcularPi(numIteracoes);

    cout << "O valor aproximado de π (pi) com " << numIteracoes << " iterações é: " << fixed << setprecision(10) << valorPi << endl;

    return 0;
}
