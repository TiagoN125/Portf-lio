#include <iostream>
using namespace std;

int main() {
    int quantidadeBatSaqueadores;
    double valorUnitario;
    double valorTotal;

    cout << "Digite a quantidade de Bat-Saqueadores que deseja comprar: ";
    cin >> quantidadeBatSaqueadores;

    cout << "Digite o valor unitário de cada moeda (em reais): ";
    cin >> valorUnitario;

    valorTotal = quantidadeBatSaqueadores * valorUnitario;

    cout << "Valor total da compra: R$ " << valorTotal << endl;

    return 0;
}
