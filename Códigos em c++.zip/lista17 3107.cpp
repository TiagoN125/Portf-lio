#include <iostream>

int main() {
    const int tamanhoVetor = 5;
    char vetor[tamanhoVetor];

    std::cout << "Digite " << tamanhoVetor << " letras do alfabeto:\n";

    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << "Letra " << i + 1 << ": ";
        std::cin >> vetor[i];
    }

    char letraBuscada;
    std::cout << "\nDigite uma letra para verificar se está presente no vetor: ";
    std::cin >> letraBuscada;

    bool encontrada = false;

    for (int i = 0; i < tamanhoVetor; i++) {
        if (vetor[i] == letraBuscada) {
            encontrada = true;
            break;
        }
    }

    if (encontrada) {
        std::cout << "A letra '" << letraBuscada << "' está presente no vetor.\n";
    } else {
        std::cout << "A letra '" << letraBuscada << "' não está presente no vetor.\n";
    }

    return 0;
}
