#include <iostream>
#include <cstdlib> // Incluir a biblioteca cstdlib para usar a função rand()
#include <ctime> // Incluir a biblioteca ctime para usar a função time()

int main() {
    const int tamanhoVetor = 4;
    int vetor[tamanhoVetor];

    // Inicializa o gerador de números aleatórios com o valor do relógio
    std::srand(std::time(0));

    // Preenche o vetor com valores aleatórios entre 1 e 10
    for (int i = 0; i < tamanhoVetor; i++) {
        vetor[i] = std::rand() % 10 + 1;
    }

    std::cout << "Tente adivinhar um dos números do vetor (valores entre 1 e 10):\n";
    int palpite;
    std::cin >> palpite;

    bool acertou = false;
    for (int i = 0; i < tamanhoVetor; i++) {
        if (vetor[i] == palpite) {
            acertou = true;
            break;
        }
    }

    if (acertou) {
        std::cout << "Parabéns! Você acertou o palpite.\n";
    } else {
        std::cout << "Você errou o palpite. Os números do vetor são: ";
        for (int i = 0; i < tamanhoVetor; i++) {
            std::cout << vetor[i] << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}
