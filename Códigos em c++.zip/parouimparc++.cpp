#include <iostream>

int main() {
    int numero;

    // Solicita ao usuário que digite o número
    std::cout << "Digite um número inteiro: ";
    std::cin >> numero;

    // Verifica se o número é par ou ímpar
    if (numero % 2 == 0) {
        std::cout << numero << " é um número par." << std::endl;
    } else {
        std::cout << numero << " é um número ímpar." << std::endl;
    }

    return 0;
}
