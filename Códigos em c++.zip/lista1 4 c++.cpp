#include <iostream>
using namespace std;

int main() {
    int numero, soma = 0, quantidade = 0;

    cout << "Digite uma sequência de números inteiros (digite 0 para encerrar):" << endl;

    while (true) {
        cin >> numero;
        
        if (numero == 0) {
            break; // Encerra o loop quando o número digitado for zero
        }

        soma += numero;
        quantidade++;
    }

    if (quantidade == 0) {
        cout << "Nenhum número foi digitado." << endl;
    } else {
        float media = static_cast<float>(soma) / quantidade;
        cout << "A média dos números digitados é: " << media << endl;
    }

    return 0;
}