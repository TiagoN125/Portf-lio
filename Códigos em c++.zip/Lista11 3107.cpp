#include <iostream>

int main() {
    const int tamanhoVetor = 5;
    int vetor[tamanhoVetor];

    std::cout << "Digite " << tamanhoVetor << " valores inteiros:\n";

    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << "Elemento " << i + 1 << ": ";
        std::cin >> vetor[i];
    }

    std::cout << "\nValores digitados:\n";
    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << vetor[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}
