#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    string nomeArquivo;

    cout << "Digite o nome do arquivo de código-fonte (com extensão .cpp): ";
    cin >> nomeArquivo;

    ifstream arquivo(nomeArquivo);

    if (arquivo) {
        cout << "Compilando " << nomeArquivo << "... Compilação concluída com sucesso!" << endl;
    } else {
        cout << "Arquivo não encontrado." << endl;
    }

    return 0;
}
