#include <iostream>

int main() {
    int idade;

    // Solicita ao usuário que digite a idade
    std::cout << "Digite a idade: ";
    std::cin >> idade;

    // Verifica se a idade é maior ou igual a 18 anos
    if (idade >= 18) {
        std::cout << "Maior de idade" << std::endl;
    } else {
        std::cout << "Menor de idade" << std::endl;
    }

    return 0;
}
