#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int main() {
    string aliado1, aliado2, aliado3;

    cout << "Digite o nome do primeiro aliado do Batman: ";
    getline(cin, aliado1);

    cout << "Digite o nome do segundo aliado do Batman: ";
    getline(cin, aliado2);

    cout << "Digite o nome do terceiro aliado do Batman: ";
    getline(cin, aliado3);

    // Ordenando os nomes dos aliados em ordem alfabética
    sort(aliado1.begin(), aliado1.end());
    sort(aliado2.begin(), aliado2.end());
    sort(aliado3.begin(), aliado3.end());

    cout << "Os aliados do Batman em ordem alfabética são:" << endl;
    cout << aliado1 << endl;
    cout << aliado2 << endl;
    cout << aliado3 << endl;

    return 0;
}
