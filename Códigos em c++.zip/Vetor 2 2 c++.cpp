#include <iostream>
#include <string>
#include <vector>

int main() {
    // Declarando o vetor de países e seus títulos
    std::vector<std::string> paises = {"Brasil", "Estados Unidos", "Alemanha", "Noruega", "Japão", "Suécia", "China", "Canadá"};
    std::vector<int> titulos = {7, 4, 2, 0, 1, 0, 0, 0};

    // Exibindo os países que nunca venceram o torneio (com 0 títulos)
    std::cout << "Países que nunca venceram a Copa do Mundo Feminina:\n";
    for (size_t i = 0; i < paises.size(); ++i) {
        if (titulos[i] == 0) {
            std::cout << paises[i] << std::endl;
        }
    }

    return 0;
}