#include <iostream>
#include <string>
using namespace std;

bool verificarPalindromo(int numero) {
    string numeroStr = to_string(numero);
    int tamanho = numeroStr.length();

    for (int i = 0; i < tamanho / 2; i++) {
        if (numeroStr[i] != numeroStr[tamanho - 1 - i]) {
            return false;
        }
    }

    return true;
}

int main() {
    int numero;

    cout << "Digite um número inteiro: ";
    cin >> numero;

    if (verificarPalindromo(numero)) {
        cout << numero << " é um número palíndromo." << endl;
    } else {
        cout << numero << " não é um número palíndromo." << endl;
    }

    return 0;
}