#include <iostream>
#include <string>

int main() {
    const int tamanhoVetor = 7;
    char siglasPaises[tamanhoVetor] = {'B', 'C', 'E', 'F', 'S', 'U', 'Z'};
    char siglaBuscada;

    // Solicitando a sigla ao usuário
    std::cout << "Digite a sigla de um país: ";
    std::cin >> siglaBuscada;

    // Verificando se a sigla está presente no vetor
    bool encontrou = false;
    for (int i = 0; i < tamanhoVetor; ++i) {
        if (siglasPaises[i] == siglaBuscada) {
            encontrou = true;
            break;
        }
    }

    // Exibindo o resultado
    if (encontrou) {
        std::cout << "A sigla " << siglaBuscada << " está presente no vetor.\n";
    } else {
        std::cout << "A sigla " << siglaBuscada << " não está presente no vetor.\n";
    }

    return 0;
}
