#include <iostream>

bool isPrimo(int numero) {
    if (numero <= 1) {
        return false;
    }

    for (int i = 2; i * i <= numero; i++) {
        if (numero % i == 0) {
            return false;
        }
    }

    return true;
}

int main() {
    int numero;

    // Solicita ao usuário que digite o número
    std::cout << "Digite um número inteiro: ";
    std::cin >> numero;

    // Verifica se o número é primo
    if (isPrimo(numero)) {
        std::cout << numero << " é um número primo." << std::endl;
    } else {
        std::cout << numero << " não é um número primo." << std::endl;
    }

    return 0;
}
