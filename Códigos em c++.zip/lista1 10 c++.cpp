#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int lancarDado() {
    return rand() % 6 + 1; // Retorna um número aleatório entre 1 e 6
}

int main() {
    srand(time(0)); // Inicializa a semente do gerador de números aleatórios

    int resultado, lancamentos = 0;

    do {
        resultado = lancarDado();
        lancamentos++;
    } while (resultado != 6);

    cout << "O jogador atingiu o resultado 6 após " << lancamentos << " lançamentos." << endl;

    return 0;
}
