#include <iostream>
#include <iomanip>
#include <string>

int main() {
    bool valor1, valor2;

    // Solicita ao usuário que digite os dois valores booleanos
    std::cout << "Digite o primeiro valor (true ou false): ";
    std::cin >> std::boolalpha >> valor1;

    std::cout << "Digite o segundo valor (true ou false): ";
    std::cin >> std::boolalpha >> valor2;

    // Realiza as operações lógicas AND, OR e NOT
    bool resultadoAND = valor1 && valor2;
    bool resultadoOR = valor1 || valor2;
    bool resultadoNOT1 = !valor1;
    bool resultadoNOT2 = !valor2;

    // Exibe os resultados
    std::cout << std::boolalpha << "Resultado da operação AND: " << resultadoAND << std::endl;
    std::cout << std::boolalpha << "Resultado da operação OR: " << resultadoOR << std::endl;
    std::cout << std::boolalpha << "Resultado da operação NOT (valor 1): " << resultadoNOT1 << std::endl;
    std::cout << std::boolalpha << "Resultado da operação NOT (valor 2): " << resultadoNOT2 << std::endl;

    return 0;
}
