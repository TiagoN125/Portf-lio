#include <iostream>
using namespace std;

int main() {
    float fahrenheit, celsius;

    cout << "Digite a temperatura em graus Fahrenheit: ";
    cin >> fahrenheit;

    celsius = (fahrenheit - 32) * 5 / 9;

    cout << "A temperatura em graus Celsius é: " << celsius << " °C" << endl;

    return 0;
}
