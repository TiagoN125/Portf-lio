#include <iostream>

int main() {
    const int tamanhoVetor = 6;
    int vetor[tamanhoVetor];

    std::cout << "Digite " << tamanhoVetor << " números inteiros:\n";

    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << "Elemento " << i + 1 << ": ";
        std::cin >> vetor[i];
    }

    // Inverte a ordem dos elementos do vetor
    for (int i = 0; i < tamanhoVetor / 2; i++) {
        int temp = vetor[i];
        vetor[i] = vetor[tamanhoVetor - 1 - i];
        vetor[tamanhoVetor - 1 - i] = temp;
    }

    std::cout << "\nVetor resultante (após inverter a ordem dos elementos):\n";
    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << vetor[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}
