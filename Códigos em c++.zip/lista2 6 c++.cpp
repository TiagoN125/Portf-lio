#include <iostream>
using namespace std;

bool verificarPrimo(int numero) {
    if (numero <= 1) {
        return false; // Números menores ou iguais a 1 não são primos
    }

    for (int i = 2; i * i <= numero; i++) {
        if (numero % i == 0) {
            return false; // Se for divisível por algum número entre 2 e a raiz quadrada do número, não é primo
        }
    }

    return true;
}

int main() {
    int numero;

    cout << "Digite um número inteiro: ";
    cin >> numero;

    cout << "Números primos menores ou iguais a " << numero << ":" << endl;

    for (int i = 2; i <= numero; i++) {
        if (verificarPrimo(i)) {
            cout << i << " ";
        }
    }

    cout << endl;

    return 0;
}
