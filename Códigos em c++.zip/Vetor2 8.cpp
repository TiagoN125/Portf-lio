#include <iostream>

int main() {
    const int tamanhoVetor = 6;
    int datasJogos[tamanhoVetor];

    // Preenchendo o vetor com as datas dos jogos
    std::cout << "Digite as datas dos jogos:\n";
    for (int i = 0; i < tamanhoVetor; ++i) {
        std::cin >> datasJogos[i];
    }

    // Invertendo a ordem das datas no vetor
    int inicio = 0;
    int fim = tamanhoVetor - 1;
    while (inicio < fim) {
        int temp = datasJogos[inicio];
        datasJogos[inicio] = datasJogos[fim];
        datasJogos[fim] = temp;
        inicio++;
        fim--;
    }

    // Exibindo o vetor resultante
    std::cout << "Vetor invertido:\n";
    for (int i = 0; i < tamanhoVetor; ++i) {
        std::cout << datasJogos[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}
