#include <iostream>

int main() {
    double num1, num2;

    // Solicita ao usuário que digite os dois números
    std::cout << "Digite o primeiro número: ";
    std::cin >> num1;

    std::cout << "Digite o segundo número: ";
    std::cin >> num2;

    // Calcula a soma dos números
    double soma = num1 + num2;

    // Exibe o resultado da soma
    std::cout << "A soma dos números é: " << soma << std::endl;

    return 0;
}
