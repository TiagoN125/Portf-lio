#include <iostream>
#include <limits> // Incluir a biblioteca limits para usar o std::numeric_limits

int main() {
    const int tamanhoVetor = 7;
    float vetor[tamanhoVetor];

    std::cout << "Digite " << tamanhoVetor << " números reais:\n";

    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << "Elemento " << i + 1 << ": ";
        std::cin >> vetor[i];
    }

    // Inicialize as variáveis de mínimo e máximo com os valores do primeiro elemento do vetor
    float menor = vetor[0];
    float maior = vetor[0];

    // Encontre o menor e o maior valor no vetor
    for (int i = 1; i < tamanhoVetor; i++) {
        if (vetor[i] < menor) {
            menor = vetor[i];
        }
        if (vetor[i] > maior) {
            maior = vetor[i];
        }
    }

    std::cout << "\nMaior valor presente no vetor: " << maior << std::endl;
    std::cout << "Menor valor presente no vetor: " << menor << std::endl;

    return 0;
}
