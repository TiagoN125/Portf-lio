#include <iostream>

int main() {
    int numero;
    int fatorial = 1;

    // Solicita ao usuário que digite o número
    std::cout << "Digite um número inteiro: ";
    std::cin >> numero;

    // Calcula o fatorial do número
    for (int i = numero; i >= 1; i--) {
        fatorial *= i;
    }

    // Exibe o resultado do fatorial
    std::cout << "O fatorial de " << numero << " é: " << fatorial << std::endl;

    return 0;
}
