#include <iostream>
using namespace std;

void converterTempo(int segundos, int& horas, int& minutos, int& segundos_restantes) {
    horas = segundos / 3600; // 1 hora = 3600 segundos
    segundos_restantes = segundos % 3600;

    minutos = segundos_restantes / 60; // 1 minuto = 60 segundos
    segundos_restantes %= 60;
}

int main() {
    int segundos, horas, minutos, segundos_restantes;

    cout << "Digite a quantidade de segundos: ";
    cin >> segundos;

    converterTempo(segundos, horas, minutos, segundos_restantes);

    cout << "O tempo convertido é: " << horas << " horas, " << minutos << " minutos e " << segundos_restantes << " segundos." << endl;

    return 0;
}
