#include <iostream>
using namespace std;

int main() {
    int numHerois, numViloes;

    cout << "Digite a quantidade de heróis capturados pelo Batman: ";
    cin >> numHerois;

    cout << "Digite a quantidade de vilões capturados pelo Batman: ";
    cin >> numViloes;

    if (numHerois > numViloes) {
        cout << "Batman capturou mais heróis!" << endl;
    } else if (numViloes > numHerois) {
        cout << "Batman capturou mais vilões!" << endl;
    } else {
        cout << "Batman capturou a mesma quantidade de heróis e vilões!" << endl;
    }

    return 0;
}
