#include <iostream>
#include <string>

int main() {
    const int tamanhoVetor = 8;
    std::string selecoes[tamanhoVetor];

    // Preenchendo o vetor com os nomes das seleções
    std::cout << "Digite o nome das seleções que participaram da Copa do Mundo Feminina:\n";
    for (int i = 0; i < tamanhoVetor; ++i) {
        std::cin >> selecoes[i];
    }

    // Exibindo os nomes das seleções em ordem inversa
    std::cout << "Nomes das seleções em ordem inversa:\n";
    for (int i = tamanhoVetor - 1; i >= 0; --i) {
        std::cout << selecoes[i] << std::endl;
    }

    return 0;
}
