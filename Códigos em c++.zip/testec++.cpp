#include <iostream>

int main() {
    int num1, num2, num3;

    // Solicita ao usuário que digite os três números
    std::cout << "Digite o primeiro número inteiro: ";
    std::cin >> num1;

    std::cout << "Digite o segundo número inteiro: ";
    std::cin >> num2;

    std::cout << "Digite o terceiro número inteiro: ";
    std::cin >> num3;

    // Encontra o maior valor entre os três números
    int maior = num1;
    if (num2 > maior) {
        maior = num2;
    }
    if (num3 > maior) {
        maior = num3;
    }

    // Exibe o maior valor
    std::cout << "O maior valor é: " << maior << std::endl;

    return 0;
}
