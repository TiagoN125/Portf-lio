#include <iostream>
using namespace std;

void exibirSequenciaFibonacci(int n) {
    int primeiro = 0, segundo = 1, proximo;
    
    cout << "Sequência de Fibonacci até " << n << ":" << endl;
    cout << primeiro << " " << segundo << " ";

    while (true) {
        proximo = primeiro + segundo;
        if (proximo <= n) {
            cout << proximo << " ";
        } else {
            break;
        }
        primeiro = segundo;
        segundo = proximo;
    }
}

int main() {
    int numero;

    cout << "Digite um número inteiro: ";
    cin >> numero;

    exibirSequenciaFibonacci(numero);

    cout << endl;

    return 0;
}