#include <iostream>

int main() {
    const int tamanhoVetor = 10;
    int vetor[tamanhoVetor];
    int soma = 0;

    std::cout << "Digite " << tamanhoVetor << " valores inteiros:\n";

    for (int i = 0; i < tamanhoVetor; i++) {
        std::cout << "Elemento " << i + 1 << ": ";
        std::cin >> vetor[i];
    }

    for (int i = 0; i < tamanhoVetor; i++) {
        soma += vetor[i];
    }

    std::cout << "\nA soma de todos os elementos do vetor é: " << soma << std::endl;

    return 0;
}