#include <iostream>
using namespace std;

int main() {
    int numero;

    cout << "Digite um número inteiro positivo: ";
    cin >> numero;

    if (numero <= 0) {
        cout << "O número deve ser inteiro positivo." << endl;
        return 1;
    }

    cout << "Os divisores de " << numero << " são: ";
    for (int i = 1; i <= numero; i++) {
        if (numero % i == 0) {
            cout << i << " ";
        }
    }

    cout << endl;

    return 0;
}
