#include <iostream>
using namespace std;

int main() {
    int codigoAcesso;

    cout << "Digite o código de acesso (4 dígitos): ";
    cin >> codigoAcesso;

    if (codigoAcesso == 1966) {
        cout << "Acesso autorizado à Batcaverna!" << endl;
    } else {
        cout << "Acesso negado! Código de acesso incorreto." << endl;
    }

    return 0;
}
