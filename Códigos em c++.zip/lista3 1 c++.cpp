#include <iostream>
#include <string>
using namespace std;

int main() {
    string nomeComissario;

    cout << "Digite o nome do comissário: ";
    getline(cin, nomeComissario);

    cout << "Comissário " << nomeComissario << ", acione o Bat-Sinal!" << endl;

    return 0;
}
