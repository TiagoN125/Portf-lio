#include <iostream>

int main() {
    const int tamanhoVetor = 5;
    int golsMarcados[tamanhoVetor];
    int golsSofridos[tamanhoVetor];

    // Preenchendo os vetores com o número de gols marcados e gols sofridos por partida
    std::cout << "Digite o número de gols marcados em cada partida:\n";
    for (int i = 0; i < tamanhoVetor; ++i) {
        std::cin >> golsMarcados[i];
    }

    std::cout << "Digite o número de gols sofridos em cada partida:\n";
    for (int i = 0; i < tamanhoVetor; ++i) {
        std::cin >> golsSofridos[i];
    }

    // Calculando e exibindo o saldo de gols em cada partida
    std::cout << "Saldo de gols da seleção em cada partida:\n";
    for (int i = 0; i < tamanhoVetor; ++i) {
        int saldoGols = golsMarcados[i] - golsSofridos[i];
        std::cout << "Partida " << i + 1 << ": " << saldoGols << std::endl;
    }

    return 0;
}
