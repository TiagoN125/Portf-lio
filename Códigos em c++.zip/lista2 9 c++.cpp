#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    srand(static_cast<unsigned>(time(0))); // Inicializa a semente do gerador de números aleatórios
    int numeroAleatorio = rand() % 100 + 1; // Gera um número aleatório entre 1 e 100
    int tentativa;
    int tentativasRestantes = 5; // Número de tentativas disponíveis

    cout << "Bem-vindo ao jogo de adivinhação!" << endl;
    cout << "Tente adivinhar um número entre 1 e 100." << endl;

    while (tentativasRestantes > 0) {
        cout << "Tentativa " << 6 - tentativasRestantes << ": ";
        cin >> tentativa;

        if (tentativa == numeroAleatorio) {
            cout << "Parabéns! Você acertou o número!" << endl;
            break;
        } else if (tentativa < numeroAleatorio) {
            cout << "Tente um número maior." << endl;
        } else {
            cout << "Tente um número menor." << endl;
        }

        tentativasRestantes--;
    }

    if (tentativasRestantes == 0) {
        cout << "Suas tentativas acabaram. O número correto era: " << numeroAleatorio << endl;
    }

    return 0;
}
